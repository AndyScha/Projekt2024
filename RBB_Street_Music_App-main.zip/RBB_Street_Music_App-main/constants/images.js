
import ourlogo from "../assets/images/ourlogo.png"
import SoundSpotterLogo from "../assets/images/SoundSpotterLogo.png";
import ProfilDefault from "../assets/images/ProfilDefault.png";


export default { SoundSpotterLogo, ProfilDefault, ourlogo};
